WAX Android Studio project with Shizuku status + permission integration.
This ZIP also includes a GitHub Actions workflow to build a debug APK without a PC.

MOBILE BUILD VIA GITHUB:
1. Sign in to GitHub in your phone browser.
2. Create a new repository. Keep it private if you prefer.
3. Upload the CONTENTS of this ZIP (including the hidden .github folder).
   If your ZIP/file manager hides .github, use GitHub's web upload or add
   .github/workflows/build-apk.yml manually using the workflow file in this ZIP.
4. Open the repository's Actions tab.
5. Select "Build WAX APK", tap "Run workflow", then run it.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, find Artifacts, and download WAX-debug-apk.
8. Extract the artifact ZIP; install app-debug.apk on your Android phone.
   Android may ask you to allow installs from your browser/file manager.

Build requirements are handled by GitHub Actions (Java 17, Gradle 8.7).
This is an unsigned debug APK intended for personal testing, not Play Store release.

Shizuku notes:
- Shizuku must be installed and running; grant WAX the permission when prompted.
- This app checks Shizuku binder availability and WAX permission only.
- It does not perform actions on game servers or modify game accounts.
