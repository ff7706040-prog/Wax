package com.wax.terminal;

import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 7301;
    private WebView webView;

    private final Shizuku.OnBinderReceivedListener binderReceived = this::refreshStatus;
    private final Shizuku.OnBinderDeadListener binderDead = this::refreshStatus;
    private final Shizuku.OnRequestPermissionResultListener permissionResult =
        (requestCode, grantResult) -> {
            if (requestCode == REQUEST_CODE) refreshStatus();
        };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF030906);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new WaxBridge(), "WaxNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);

        Shizuku.addBinderReceivedListenerSticky(binderReceived);
        Shizuku.addBinderDeadListener(binderDead);
        Shizuku.addRequestPermissionResultListener(permissionResult);

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void refreshStatus() {
        runOnUiThread(() -> {
            if (webView != null) {
                boolean running = Shizuku.pingBinder();
                boolean granted = running &&
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
                String state = !running ? "DISCONNECTED" : (granted ? "CONNECTED & AUTHORIZED" : "CONNECTED — PERMISSION NEEDED");
                String js = "window.onNativeShizukuStatus && window.onNativeShizukuStatus("
                    + JSONObjectQuote(state) + "," + running + "," + granted + ")";
                webView.evaluateJavascript(js, null);
            }
        });
    }

    private String JSONObjectQuote(String value) {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    private class WaxBridge {
        @JavascriptInterface
        public void checkStatus() {
            refreshStatus();
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> {
                if (!Shizuku.pingBinder()) {
                    refreshStatus();
                    return;
                }
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    refreshStatus();
                } else {
                    Shizuku.requestPermission(REQUEST_CODE);
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived);
        Shizuku.removeBinderDeadListener(binderDead);
        Shizuku.removeRequestPermissionResultListener(permissionResult);
        if (webView != null) {
            webView.removeJavascriptInterface("WaxNative");
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
